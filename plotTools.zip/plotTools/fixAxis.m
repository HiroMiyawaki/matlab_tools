function ax=fixAxis
    ax=axis();
    xlim(ax(1:2));
    ylim(ax(3:4));
    